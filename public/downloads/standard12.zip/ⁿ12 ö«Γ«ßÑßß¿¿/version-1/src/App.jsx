import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import MySessions from './pages/MySessions'
import BookSession from './pages/BookSession'
import './App.css'

function App() {
  return (
    <div className="app">
      <Layout>
        <Routes>
          <Route path="/" element={<MySessions />} />
          <Route path="/book" element={<BookSession />} />
        </Routes>
      </Layout>
    </div>
  )
}

export default App

