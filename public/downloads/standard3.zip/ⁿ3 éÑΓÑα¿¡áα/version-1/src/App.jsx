import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import MyVisits from './pages/MyVisits'
import BookVisit from './pages/BookVisit'

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<MyVisits />} />
          <Route path="/book" element={<BookVisit />} />
        </Routes>
      </Layout>
    </Router>
  )
}

export default App

