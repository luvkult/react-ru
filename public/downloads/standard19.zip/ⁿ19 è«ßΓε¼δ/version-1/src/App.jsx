import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import MyRentals from './pages/MyRentals'
import RentCostume from './pages/RentCostume'
import './App.css'

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<MyRentals />} />
          <Route path="/rent" element={<RentCostume />} />
        </Routes>
      </Layout>
    </Router>
  )
}

export default App

