import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import MyLessons from './pages/MyLessons'
import BookLesson from './pages/BookLesson'

function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<MyLessons />} />
        <Route path="/book" element={<BookLesson />} />
      </Routes>
    </Layout>
  )
}

export default App
