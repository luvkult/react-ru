import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import MyCourses from './pages/MyCourses'
import Enroll from './pages/Enroll'

function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<MyCourses />} />
          <Route path="/enroll" element={<Enroll />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  )
}

export default App
