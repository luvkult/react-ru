import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import MyRentals from './pages/MyRentals'
import BookRental from './pages/BookRental'

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<MyRentals />} />
          <Route path="/book" element={<BookRental />} />
        </Routes>
      </Layout>
    </Router>
  )
}

export default App

