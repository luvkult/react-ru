import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import VisitHistory from './pages/VisitHistory'
import BookAppointment from './pages/BookAppointment'

function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<VisitHistory />} />
        <Route path="/book" element={<BookAppointment />} />
      </Routes>
    </Layout>
  )
}

export default App
