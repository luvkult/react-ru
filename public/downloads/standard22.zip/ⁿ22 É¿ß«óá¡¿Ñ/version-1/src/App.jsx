import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import MyLessons from './pages/MyLessons'
import Enroll from './pages/Enroll'

function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<MyLessons />} />
        <Route path="/enroll" element={<Enroll />} />
      </Routes>
    </Layout>
  )
}

export default App

