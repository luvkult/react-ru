import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import MyOrders from './pages/MyOrders'
import BookBook from './pages/BookBook'

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<MyOrders />} />
          <Route path="/book" element={<BookBook />} />
        </Routes>
      </Layout>
    </Router>
  )
}

export default App

