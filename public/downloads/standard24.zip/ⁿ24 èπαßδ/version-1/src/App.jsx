import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import MyApplications from './pages/MyApplications'
import Enroll from './pages/Enroll'

function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<MyApplications />} />
          <Route path="/enroll" element={<Enroll />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  )
}

export default App
