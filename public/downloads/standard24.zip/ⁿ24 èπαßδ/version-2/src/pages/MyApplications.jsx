import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { Calendar, Clock, CheckCircle, MessageSquare, Star, FileText, Plus } from 'lucide-react'
import ImageSlider from '../components/ImageSlider'
import './MyApplications.css'

const MyApplications = () => {
  const navigate = useNavigate()
  const [applications, setApplications] = useState([])

  useEffect(() => {
    const saved = localStorage.getItem('courseApplications')
    if (saved) {
      try {
        setApplications(JSON.parse(saved))
      } catch (e) {
        setApplications([])
      }
    } else {
      const defaultApps = [
        {
          id: 1,
          courseName: 'Основы алгоритмизации и программирования',
          startDate: '2025-05-15',
          status: 'active',
          review: null
        },
        {
          id: 2,
          courseName: 'Основы веб-дизайна',
          startDate: '2025-04-20',
          status: 'completed',
          review: {
            rating: 5,
            text: 'Отличный курс! Очень понравилась подача материала.'
          }
        },
        {
          id: 3,
          courseName: 'Основы проектирования баз данных',
          startDate: '2025-03-10',
          status: 'completed',
          review: null
        }
      ]
      setApplications(defaultApps)
      localStorage.setItem('courseApplications', JSON.stringify(defaultApps))
    }
  }, [])

  const handleReviewSubmit = (applicationId, rating, text) => {
    const updated = applications.map(app => {
      if (app.id === applicationId) {
        return {
          ...app,
          review: { rating, text }
        }
      }
      return app
    })
    setApplications(updated)
    localStorage.setItem('courseApplications', JSON.stringify(updated))
  }

  const handleComplete = (applicationId) => {
    const updated = applications.map(app => {
      if (app.id === applicationId) {
        return {
          ...app,
          status: 'completed'
        }
      }
      return app
    })
    setApplications(updated)
    localStorage.setItem('courseApplications', JSON.stringify(updated))
  }

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('ru-RU', { 
      day: 'numeric', 
      month: 'long', 
      year: 'numeric' 
    })
  }

  const totalCount = applications.length
  const activeCount = applications.filter(a => a.status === 'active').length
  const completedCount = applications.filter(a => a.status === 'completed').length

  return (
    <div className="applications-split">
      <div className="split-layout">
        <aside className="sidebar-split">
          <div className="sidebar-content">
            <div className="sidebar-header">
              <h2 className="sidebar-title">Мои заявки</h2>
              <p className="sidebar-subtitle">Управление курсами</p>
            </div>
            
            <div className="stats-minimal">
              <div className="stat-minimal">
                <div className="stat-value-minimal">{totalCount}</div>
                <div className="stat-label-minimal">Всего заявок</div>
              </div>
              <div className="stat-minimal">
                <div className="stat-value-minimal">{activeCount}</div>
                <div className="stat-label-minimal">Активных</div>
              </div>
              <div className="stat-minimal">
                <div className="stat-value-minimal">{completedCount}</div>
                <div className="stat-label-minimal">Завершено</div>
              </div>
            </div>

            <button className="new-application-btn" onClick={() => navigate('/enroll')}>
              <Plus size={20} />
              <span>Новая заявка</span>
            </button>
          </div>
        </aside>

        <main className="main-panel-split">
          <div className="container">
            <section className="page-header-split">
              <h1 className="page-title-split">Заявки на курсы</h1>
              <p className="page-description-split">
                Просматривайте свои заявки, отслеживайте статус обучения и делитесь отзывами
              </p>
            </section>

            <ImageSlider />

            <section className="applications-list-split">
              {applications.length === 0 ? (
                <div className="empty-state-split">
                  <div className="empty-icon-wrapper">
                    <FileText size={64} />
                  </div>
                  <h2 className="empty-title-split">Нет заявок</h2>
                  <p className="empty-text-split">Создайте первую заявку на курс</p>
                  <button 
                    className="empty-button-split" 
                    onClick={() => navigate('/enroll')}
                  >
                    Записаться на курс
                  </button>
                </div>
              ) : (
                <div className="applications-grid-split">
                  {applications.map((application) => (
                    <ApplicationCard
                      key={application.id}
                      application={application}
                      onReviewSubmit={handleReviewSubmit}
                      onComplete={handleComplete}
                      formatDate={formatDate}
                    />
                  ))}
                </div>
              )}
            </section>
          </div>
        </main>
      </div>
    </div>
  )
}

const ApplicationCard = ({ application, onReviewSubmit, onComplete, formatDate }) => {
  const [rating, setRating] = useState(application.review?.rating || 0)
  const [reviewText, setReviewText] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = () => {
    if (rating === 0 || !reviewText.trim()) {
      alert('Пожалуйста, выберите рейтинг и напишите отзыв')
      return
    }
    setIsSubmitting(true)
    onReviewSubmit(application.id, rating, reviewText)
    setIsSubmitting(false)
    setReviewText('')
    setRating(0)
  }

  return (
    <div className={`application-item-split ${application.status}`}>
      <div className="item-header-split">
        <div className="item-number-split">#{application.id}</div>
        <div className={`status-indicator-split ${application.status}`}>
          {application.status === 'active' ? (
            <>
              <Clock size={16} />
              <span>Активна</span>
            </>
          ) : (
            <>
              <CheckCircle size={16} />
              <span>Завершена</span>
            </>
          )}
        </div>
      </div>
      <h3 className="item-title-split">{application.courseName}</h3>
      <div className="item-meta-split">
        <Calendar size={18} />
        <span>{formatDate(application.startDate)}</span>
      </div>
      
      {application.status === 'active' && (
        <div className="complete-section-split">
          <button
            className="complete-btn-split"
            onClick={() => onComplete(application.id)}
          >
            <CheckCircle size={18} />
            <span>Завершить курс</span>
          </button>
        </div>
      )}
      
      {application.status === 'completed' && (
        <div className="review-section-split">
          {application.review ? (
            <div className="review-display-split">
              <div className="review-stars-split">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    size={20}
                    fill={i < application.review.rating ? '#F59E0B' : 'none'}
                    color={i < application.review.rating ? '#F59E0B' : '#94A3B8'}
                  />
                ))}
              </div>
              <p className="review-text-split">{application.review.text}</p>
            </div>
          ) : (
            <div className="review-form-split">
              <div className="review-header-split">
                <MessageSquare size={20} />
                <span>Оставить отзыв о качестве образовательных услуг</span>
              </div>
              <p className="review-hint-split">Оцените курс по 5-балльной шкале и поделитесь своими впечатлениями</p>
              <div className="rating-split">
                <span className="rating-label-split">Рейтинг:</span>
                {Array.from({ length: 5 }).map((_, i) => (
                  <button
                    key={i}
                    type="button"
                    className="star-btn-split"
                    onClick={() => setRating(i + 1)}
                    title={`Оценить на ${i + 1} ${i === 0 ? 'звезду' : i < 4 ? 'звезды' : 'звезд'}`}
                  >
                    <Star
                      size={28}
                      fill={i < rating ? '#F59E0B' : 'none'}
                      color={i < rating ? '#F59E0B' : '#94A3B8'}
                    />
                  </button>
                ))}
                {rating > 0 && <span className="rating-value-split">{rating} из 5</span>}
              </div>
              <div className="textarea-wrapper-split">
                <label htmlFor={`review-text-${application.id}`} className="textarea-label-split">
                  Ваш отзыв:
                </label>
                <textarea
                  id={`review-text-${application.id}`}
                  className="review-textarea-split"
                  placeholder="Расскажите о вашем опыте обучения, что понравилось, что можно улучшить..."
                  rows="4"
                  value={reviewText}
                  onChange={(e) => setReviewText(e.target.value)}
                />
              </div>
              <button
                className="submit-review-split"
                onClick={handleSubmit}
                disabled={isSubmitting || rating === 0 || !reviewText.trim()}
              >
                {isSubmitting ? 'Отправка...' : 'Отправить отзыв'}
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

export default MyApplications

