import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import MyConsultations from './pages/MyConsultations'
import Enroll from './pages/Enroll'

function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<MyConsultations />} />
        <Route path="/enroll" element={<Enroll />} />
      </Routes>
    </Layout>
  )
}

export default App
