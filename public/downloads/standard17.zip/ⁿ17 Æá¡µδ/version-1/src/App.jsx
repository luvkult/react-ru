import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import MyClasses from './pages/MyClasses'
import Enroll from './pages/Enroll'
import './App.css'

function App() {
  return (
    <div className="app">
      <Layout>
        <Routes>
          <Route path="/" element={<MyClasses />} />
          <Route path="/enroll" element={<Enroll />} />
        </Routes>
      </Layout>
    </div>
  )
}

export default App

