import { Routes, Route } from 'react-router-dom'
import MyParticipations from './pages/MyParticipations'
import BookClass from './pages/BookClass'
import Header from './components/Header'
import Footer from './components/Footer'

function App() {
  return (
    <div className="app">
      <Header />
      <main className="main">
        <Routes>
          <Route path="/" element={<MyParticipations />} />
          <Route path="/book" element={<BookClass />} />
        </Routes>
      </main>
      <Footer />
    </div>
  )
}

export default App

