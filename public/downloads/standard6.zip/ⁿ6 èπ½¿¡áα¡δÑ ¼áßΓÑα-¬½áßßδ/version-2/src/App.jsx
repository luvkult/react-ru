import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import MyParticipations from './pages/MyParticipations'
import BookClass from './pages/BookClass'

function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<MyParticipations />} />
        <Route path="/book" element={<BookClass />} />
      </Routes>
    </Layout>
  )
}

export default App
